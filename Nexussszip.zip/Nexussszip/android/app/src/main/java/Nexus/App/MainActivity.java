package Nexus.App;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
